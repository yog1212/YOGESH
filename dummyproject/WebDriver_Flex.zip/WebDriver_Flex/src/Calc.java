import org.openqa.selenium.firefox.FirefoxDriver;


public class Calc {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 FirefoxDriver driver = new FirefoxDriver();

		 FlexWebDriver flashApp = new FlexWebDriver(driver, "Calculator");

		driver.get("http://www.qtpselenium.com/flashapp/flash2/Calculator.html");
		
		flashApp.call("doFlexType", "text_1", "33"); // first number
   	 	flashApp.call("doFlexClick", "plus",""); // operation
   	 	flashApp.call("doFlexType", "text_2", "15"); // second number
   	 	flashApp.call("doFlexClick", "calc", "");
   	 System.out.println(flashApp.call("getFlexText", "result", ""));
	 System.out.println(flashApp.call("getFlexText", "num1", ""));

	}

}
