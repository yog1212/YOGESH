package com.testautomation.StepDef;

import java.util.Map;
import java.util.Properties;

import com.mongodb.internal.validator.UpdateFieldNameValidator;
import com.testautomation.Utility.ExcelHandler;
import com.testautomation.Utility.PropertiesFileReader;
import com.testautomation.Utility.TestDataHandler;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestDataReadingStepDef 
{
	String TestCaseNo1;
	PropertiesFileReader obj= new PropertiesFileReader();	
	TestDataHandler testdata=new TestDataHandler();
	
	@Given("^Read test data for (.*)$")
	public void read_test_data_for(String TestCaseNo) throws Throwable 
	{
		Properties properties=obj.getProperty();  
		TestCaseNo1=TestCaseNo;
		Map<String,String> TestDataInMap=ExcelHandler.getTestDataInMap(properties.getProperty("testdatafilepath"), properties.getProperty("sheetname"), TestCaseNo);
		System.out.println(TestDataInMap.get("Skill_7"));
		
		testdata.setTestDataInMap(TestDataInMap);	
		
	}
	
	@When("^Read test data with skill two$")
	public void read_test_data_for_skill_two() throws Throwable
	{
		Map<String,String> testDataInMap=testdata.getTestDataInMap();
		System.out.println(testDataInMap.get("Skill_2"));
	}

	@Then("^Read test data with skill Three$")
	public void read_test_data_for_skill_Three() throws Throwable 
	{
		Properties properties=obj.getProperty();
		Map<String,String> testDataInMap=testdata.getTestDataInMap();
		System.out.println(testDataInMap.get("Skill_3"));
		ExcelHandler.UpdateTestResultsToExcel(properties.getProperty("testdatafilepath"), properties.getProperty("sheetname"),"Pass",TestCaseNo1);
		
	}
	
	
	

}
