package net.serenity.bdd.junit.cucumber.pages;

import net.serenitybdd.core.pages.PageObject;

public class GenericPageObject extends PageObject{
	
	
	
	

}
